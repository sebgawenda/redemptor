package vchat_server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import model.DBHandler;

public class ChatServer {
    
    public static ArrayList<Socket> connectionArray = new ArrayList<>();
    public static ArrayList<String> currentUsers = new ArrayList<>();
    private static ServerSocket serverSocket;
    private static Socket client;
    private static int bytesRead;
    private static BufferedReader input;
    private static PrintWriter output;
    private static final int port = 1337;
    private static String result;
    private static String fName = "";
    private static String lName = "";
    private static String email = "";
    private static String userName = "";
    
    
    //Database
    private static DBHandler handler;
    private Connection connection;
    private PreparedStatement pst;

    public void start() throws IOException{
        System.out.println("::::::::::::::::Server::::::::::::::::");
        System.out.println("Connection starting on port: " + port);
        try{
            
            //Create connection to client on specified port
            serverSocket = new ServerSocket(port);
            System.out.println("Waiting for client(s)...");
            
            while(true){
                client = serverSocket.accept();
                connectionArray.add(client);
                Scanner input = new Scanner(client.getInputStream());
                System.out.println("\nClient connected from: " + 
                client.getRemoteSocketAddress().toString().trim());
                
                try{
                    loginAuthentication();
                    } catch (Exception e){
                        e.printStackTrace();
                    }
                addUserName(client);
                ChatServerReturn chat = new ChatServerReturn(client);
                Thread thread = new Thread(chat);
                thread.start();                
            }
            
        }catch (Exception e){
            e.printStackTrace();
        }
        
        
        
                
    }
    /*
    public static void main(String[] args) throws IOException {        
        try {
            ServerSocket server = new ServerSocket(port);
            String id;
            String pass;
            Scanner input;

            System.out.println("Waiting for client...");

            while (true) {
                Socket socket = server.accept();
                connectionArray.add(socket);

                input = new Scanner(socket.getInputStream());
              
                System.out.println("Client connected from: " + socket.getRemoteSocketAddress().toString());
   //                     + socket.getLocalAddress().getHostName());

                
                System.out.println("receive info1");
                
       // This is not working
                id = input.nextLine();
                System.out.println("client says" + id);
                pass = input.nextLine();
                
                System.out.println("ok");

                
           //     addUserName(socket);

                ChatServerReturn chat = new ChatServerReturn(socket);
                Thread thread = new Thread(chat);
                thread.start();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    */
    
    public void loginAuthentication() throws Exception{
        //open buffered reader for reading login info from client
        input = new BufferedReader(new InputStreamReader(client.getInputStream()));
        output = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
        
        String id = "";
        String pass = "";
        
        //Getting login information from client
        id = input.readLine();
        pass = input.readLine();
        
        //Testing info gathered
        System.out.println("User ID received from client: " + id);
        System.out.println("User password received from client: " + pass);
        
        handler = new DBHandler();
        connection = handler.getConnection();
        
        String q1 = "SELECT * FROM students WHERE ID=? AND password=?";
        
        try{
        pst = connection.prepareStatement(q1);
        pst.setString(1, id);
        pst.setString(2, pass);
        
        ResultSet rs = pst.executeQuery();
            
        int count = 0;
        
        
        while(rs.next()){
            count = count + 1;
            fName = rs.getString(2);
            lName = rs.getString(3);
            email = rs.getString(5); 
        }
        if(count==1){
            //send int 1 to client
            System.out.println("Login Successfull!");
            result = "1";      
            output.println(result);
            output.println(fName);
            output.println(lName);
            output.println(email);
            output.flush();
            userName = fName + " " + lName;
        }
        else{
            //send int 0 to client
            System.out.println("Username or Password is incorrect.");
            result = "0";
            output.println(result);
            output.flush();
        }
        
        } catch (Exception e){
            e.printStackTrace();
        }
        finally {
            try{
                connection.close();
            } catch (SQLException e1){
                e1.printStackTrace();
            }
        }
    }
    
    /** 
     * Method which takes in a socket input, then creates and adds a user name
     * based off input.
     * 
     * @param socket the socket of a client
     * @throws IOException 
     */
    public static void addUserName(Socket socket) throws IOException {
        currentUsers.add(userName);

        for (int i = 0; i < connectionArray.size(); i++) {
            Socket tempSocket = connectionArray.get(i);
            output = new PrintWriter(tempSocket.getOutputStream());
            output.println("#?!" + currentUsers);
            output.flush();
        }
    }
    
    public static void main(String [] args){
        ChatServer server = new ChatServer();
        try{
            server.start();
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}
