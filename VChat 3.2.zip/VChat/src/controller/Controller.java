/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import view.*;
import vchat_client.*;
//import controller.Singleton.getInstance();


/**
 *
 * @author srv_veralab
 */
public class Controller {
    
    private static SignIn signIn = new SignIn();
    private static CreateAccount createAccount = new CreateAccount();
    private static Chatroom chatroom = new Chatroom();
    private static VchatClient client = new VchatClient();
//    private static VchatClientController clientController = new VchatClientController();
    private static Singleton singleton = new Singleton();
    private static Stage stage = new Stage();
    private int ca_count = 0;
    private int cr_count = 0;
    private String id = "";
    private String password = "";
    private String ip = "";
    private String fName = "";
    private String lName = "";
    private static String userName = "";
    private String email = "";
    int result = 2;

    
    
    
    public Controller(SignIn signIn, CreateAccount createAccount, Chatroom chatroom, VchatClient client) {
        this.signIn = signIn;
        this.createAccount = createAccount;
        this.chatroom = chatroom;
        this.client = client;
        attachHandlers();

        
    }
    
    public void attachHandlers(){

        signIn.getLoginBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                /**
                * TODO
                * Gather information from login text field (here)
                * Connect to the Server thru the client (client)
                * Send student's id and password to the server (client)
                * Receive authentication from the server (client)
                *      if yes: goToChatroomStage
                *      if no: Dialog Box: "Wrong username or password"
                */

                System.out.println(":::Start controller-signIn-Login Button:::");
              
                

                //Gets information from GUI
                id = signIn.getIdTF().getText().trim();
                password = signIn.getPasswordTF().getText().trim();
                ip = signIn.getIpTF().getText().trim();
                
                //Saves information into a singleton class
                singleton.setId(id);
                singleton.setPassword(password);
                singleton.setIp(ip);
                
               
               //communicating to client
               System.out.println("testing IP: " + ip);
               client.connect(ip, id, password);
               
               if(client.getResult() == 0){
                   Alert alert = new Alert(AlertType.INFORMATION);
                   alert.setTitle("VChat - Login Unsuccessful!");
                   alert.setHeaderText(null);
                   alert.setContentText("Wrong ID or password.\nPlease try again or create an account.");
                   alert.showAndWait();
               }
               else if (client.getResult() == 1){
                   signIn.getScene().getWindow().hide();      
                    if (cr_count == 0){
                        fName = client.getfName();
                        lName = client.getlName();
                        email = client.getEmail();
                        userName = fName + " " + lName;
                        System.out.println(userName + " "+ email);
                        Scene scene = new Scene(chatroom, 600,400);
                        stage.setScene(scene);
                        stage.setTitle("VChat - Lobby");
                        chatroom.getUserCRLabel().setText("User: "+ userName);
                        chatroom.getIdCRLabel().setText("    ID: "+id);
                        chatroom.getChatroomNameLabel().setText("Chatroom: Lobby");
                        stage.setResizable(false);
                        stage.show();
                        cr_count++;
                    }else if(cr_count > 0){
                        stage.setScene(chatroom.getScene());
                        stage.setTitle("VChat Lobby");
                        chatroom.getUserCRLabel().setText("User: "+ userName);
                        chatroom.getIdCRLabel().setText("    ID: "+id);
                        chatroom.getChatroomNameLabel().setText("Chatroom: Lobby");
                        stage.setResizable(false);
                        stage.show();
                    }
               }
            }	
        });
        
        signIn.getCreateAccountBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                
                //WORKING CODE
                signIn.getScene().getWindow().hide();      
                if (ca_count == 0){
                    Scene scene = new Scene(createAccount, 400,400);
                    stage.setScene(scene);
                    stage.setTitle("Sign-Up");
                    stage.setResizable(false);
                    stage.show();
                    ca_count++;
                }else if(ca_count > 0){
                    stage.setScene(getCreateAccount().getScene());
                    stage.setTitle("Sign-Up");
                    stage.setResizable(false);
                    stage.show();
                }
            }    	
        });
        
        createAccount.getCreateAccountBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                System.out.println("pressing Create Account button");
                

            }    	
        });
        
        createAccount.getBackBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                createAccount.getScene().getWindow().hide();
                stage.setScene(getSignIn().getScene());
                stage.setTitle("Sign-In");
                stage.setResizable(false);
                stage.show();
            }    	
        });
        
        chatroom.getSendBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                if(!chatroom.getMessageTF().getText().equals("")){
                    client.getChatClient().send(chatroom.getMessageTF().getText());
                    chatroom.getMessageTF().requestFocus();    
                }
            }
        });
        
        chatroom.getHelpBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                try{
                    client.getChatClient().disconnect();
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("VChat - Sign-Out");
                    alert.setHeaderText(null);
                    alert.setContentText("You have succesfully signed-out as " + userName+"."
                    +"\nGood-bye!");
                    alert.showAndWait();
                    
                    System.exit(0);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        
    }

    /**
     * @return the signIn
     */
    public static SignIn getSignIn() {
        return signIn;
    }

    /**
     * @return the createAccount
     */
    public static CreateAccount getCreateAccount() {
        return createAccount;
    }

    /**
     * @return the chatroom
     */
    public static Chatroom getChatroom() {
        return chatroom;
    }

    /**
     * @return the client
     */
    public static VchatClient getClient() {
        return client;
    }
    
}  

