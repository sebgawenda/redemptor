
 /* To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


/**
 *
 * @author arman
 */
public class Singleton {
    
    private static Singleton instance = new Singleton();
    public static Singleton getInstance(){
        return instance;
    }
    
    //Login/Create Account Window
    private String fName;
    private String lName;
    private String email;
    private String id;
    private String password;
    private String ip;
    
    //Chatroom Window
    private TextArea chatTA;
    private ListView onlineList;

    
   
    
    
                
    /**
     * @param aInstance the instance to set
     */
    public static void setInstance(Singleton aInstance) {
        instance = aInstance;
    }

    /**
     * @return the fName
     */
    public String getfName() {
        return fName;
    }

    /**
     * @param fName the fName to set
     */
    public void setfName(String fName) {
        this.fName = fName;
    }

    /**
     * @return the lName
     */
    public String getlName() {
        return lName;
    }

    /**
     * @param lName the lName to set
     */
    public void setlName(String lName) {
        this.lName = lName;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }


    /**
     * @return the chatTA
     */
    public TextArea getChatTA() {
        return chatTA;
    }

    /**
     * @param chatTA the chatTA to set
     */
    public void setChatTA(TextArea chatTA) {
        this.chatTA = chatTA;
    }

    /**
     * @return the onlineList
     */
    public ListView getOnlineList() {
        return onlineList;
    }

    /**
     * @param onlineList the onlineList to set
     */
    public void setOnlineList(ListView onlineList) {
        this.onlineList = onlineList;
    }

    /**
     * @return the ip
     */
    public String getIp() {
        return ip;
    }

    /**
     * @param ip the ip to set
     */
    public void setIp(String ip) {
        this.ip = ip;
    }

    
}
