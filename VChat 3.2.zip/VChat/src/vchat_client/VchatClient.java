/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vchat_client;

import controller.Singleton;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
//import controller.Singleton;

public class VchatClient {
    
    Singleton clientInfo = new Singleton();
    private VchatClientController chatClient;
    private String host = "localhost";
    private Socket socket;
    private PrintWriter output;
    private BufferedReader read;
    private int result = 2;
    final int port = 1337;
    private String fName = "";
    private String lName = "";
    private String email = "";
    private static String userName = "";

    public void connect(String ip, String id, String pass) {
        
        System.out.println(":::Start vchat_client-VchatClient-connect:::");
        System.out.println("Attempting to connect to server with ip address: " + ip);
        
        try {   
            //Connected to server
            socket = new Socket(ip, port);
            System.out.println("You are connected to server with IP Address: " + ip);
            
            //Sending login info to server
            output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
            output.println(id);
            output.println(pass);
            output.flush();
            
            //Receiving login authentication from server
            read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String loginAuth = read.readLine();
            result = Integer.parseInt(loginAuth); 

            if(getResult() == 1){
                System.out.println("Login Successful!");
                fName = read.readLine();
                lName = read.readLine();
                email = read.readLine();
                userName = fName + " " + lName;
                
                try{
                chatClient = new VchatClientController(socket);
                Thread t = new Thread((Runnable) getChatClient());
                t.start();
                }catch (Exception e){
                    e.printStackTrace();
                }
                
            }else if (getResult() == 0){
                System.out.println("Login Unsuccessful! Wrong ID or password.");
            }
            
            
            
            
            
            /*
            //Receiving authentication response from server
            read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String response = read.readLine();
            System.out.println("This is the response: " + response);
            
            
            /*
            setChatClient(new VchatClientController(socket)); 
            PrintWriter output = new PrintWriter(socket.getOutputStream());
//            output.println(getfName() + " " + getlName());
            output.flush();
            Thread t = new Thread((Runnable) getChatClient());
            t.start();
            */
            
        } catch(Exception e) {
            System.out.println(e);
            System.out.println("Server not responding...");
            //JOptionPane.showMessageDialog(null, "Server not responding.");
            System.exit(0);
        }
    }

    
    

    /**
     * @return the chatClient
     */
    public VchatClientController getChatClient() {
        return chatClient;
    }

    /**
     * @param aChatClient the chatClient to set
     */
    public void setChatClient(VchatClientController aChatClient) {
        chatClient = aChatClient;
    }

   
    /**
     * @return the host
     */
    public String getHost() {
        return host;
    }

    /**
     * @param host the host to set
     */
    public void setHost(String host) {
        this.host = host;
    }

    /**
     * @return the result
     */
    public int getResult() {
        return result;
    }

    /**
     * @return the fName
     */
    public String getfName() {
        return fName;
    }

    /**
     * @return the lName
     */
    public String getlName() {
        return lName;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @return the userName
     */
    public static String getUserName() {
        return userName;
    }
    
}
