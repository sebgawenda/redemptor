package client_package;

import server_package.ChatServer;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;


public class VChat_ClientMain {
    private static VChat_ClientController chatClient;
    private static String userName = "Vaquero";
    
   /*
    * Components for Login Window
    */   
    private static JFrame loginWindow = new JFrame();
    
    private static JLabel idLabel = new JLabel("Student ID: ");
    private static JTextField idTF = new JTextField(10);
    
    private static JLabel passwordLabel = new JLabel("Password: ");
    //private static JTextField passwordTF = new JTextField(20);
    
    private static JButton signInBtn = new JButton("Sign In");
    private static JButton createAccountBtn = new JButton("Create Account");
    
    
   /*
    * Components for chatroom
    */
    private static JFrame mainWindow = new JFrame();
    
    private static JButton aboutButton = new JButton();
    private static JButton connectButton = new JButton();
    private static JButton disconnectButton = new JButton();
    private static JButton helpButton = new JButton();
    private static JButton sendButton = new JButton();
    
    private static JLabel messageLabel = new JLabel("Message: ");
    private static JTextField messageTF = new JTextField(20);
    
    private static JLabel conversationLabel = new JLabel();
    private static JTextArea conversationTA = new JTextArea();
    private static JScrollPane conversationSP = new JScrollPane();
    
    private static JLabel onlineLabel = new JLabel();
    private static JList onlineList = new JList();
    private static JScrollPane onlineSP = new JScrollPane();
    
    private static JLabel loggedInAsLabel = new JLabel();
    private static JLabel loggedInAsBox = new JLabel();
    
    /* GUI Globals Login Window */
    private static JFrame logInWindow = new JFrame();
    private static JTextField userNameTF = new JTextField(20);
    private static JTextField passwordTF = new JTextField(20);
    private static JButton enterButton = new JButton("Enter");
    private static JLabel enterUserLabel = new JLabel("Enter username: ");
    private static JLabel enterPasswdLabel = new JLabel("Enter password: ");
    private static JPanel logInPanel = new JPanel();
    
    //Added ip address window to input ip of server computer
    private static JFrame ipAddressWindow = new JFrame();
    private static JLabel enterIPAddress = new JLabel("Enter host's IP address: ");
    private static JTextField ipAddressTF = new JTextField(20);
    private static JButton enterButtonIP = new JButton("Enter");
    private static JPanel ipAddressPanel = new JPanel();
    
    private static String hostInput = "";
  
    
    /**
     * Main method used to run the GUI.
     * @param args 
     */
    public static void main (String args[]) {
        buildMainWindow();
        initialize();
    }
    
    public static void buildLoginWindow() {
        loginWindow.setTitle("VChat Sign In");
        loginWindow.setSize(432, 422);
        loginWindow.setLocation(220, 180);
        loginWindow.setResizable(false);
        configureLoginWindow();
        //loginWindowActions();
        loginWindow.setVisible(true);
        
    }
    
    /**
     * Method to build our main GUI.
     */
    public static void buildMainWindow() {
        mainWindow.setTitle(getUserName() + "'s Chat Box");
        mainWindow.setSize(450, 500);
        mainWindow.setLocation(220, 180);
        mainWindow.setResizable(false);
        configureMainWindow();
        mainWindowActions();
        mainWindow.setVisible(true);
        
    }
    public static void configureLoginWindow() {
        /*
        private static JLabel idLabel = new JLabel("Student ID: ");
    private static JTextField idTF = new JTextField(10);
    
    private static JLabel passwordLabel = new JLabel("Password: ");
    private static JTextField passwordTF = new JTextField(20);
    
    private static JButton signInBtn = new JButton("Sign In");
    private static JButton createAccountBtn = new JButton("Create Account");
        */
        loginWindow.setBackground(Color.white);
        loginWindow.setSize(432, 422);
        loginWindow.getContentPane().setLayout(null);
        
        signInBtn.setBackground(Color.orange);
        signInBtn.setForeground(Color.white);
        signInBtn.setText("Sign In");
        loginWindow.getContentPane().add(signInBtn);
        //signInBtn.setBounds();
        
        
    }
    /**
     * Method which assigns values such as color, size and alignment
     * to our buttons, labels, text fields, text areas, and scroll panes. 
     */
    public static void configureMainWindow() {
        mainWindow.setBackground(Color.white);
        mainWindow.setSize(500, 320);        
        mainWindow.getContentPane().setLayout(null);
        
        sendButton.setBackground(Color.orange);
        sendButton.setForeground(Color.white);
        sendButton.setText("Send");
        mainWindow.getContentPane().add(sendButton);
        sendButton.setBounds(250, 40, 81, 25);
        
        disconnectButton.setBackground(Color.orange);
        disconnectButton.setForeground(Color.white);
        disconnectButton.setText("Disconnect");
        mainWindow.getContentPane().add(disconnectButton);
        disconnectButton.setBounds(10, 40, 110, 25);
        
        connectButton.setBackground(Color.orange);
        connectButton.setForeground(Color.white);
        connectButton.setText("Connect");
        mainWindow.getContentPane().add(connectButton);
        connectButton.setBounds(130, 40, 110, 25);
        
        helpButton.setBackground(Color.orange);
        helpButton.setForeground(Color.white);
        helpButton.setText("Help");
        mainWindow.getContentPane().add(helpButton);
        helpButton.setBounds(420, 40, 70, 25);
        
        aboutButton.setBackground(Color.orange);
        aboutButton.setForeground(Color.white);
        aboutButton.setText("Help");
        mainWindow.getContentPane().add(aboutButton);
        aboutButton.setBounds(340, 40, 75, 25);
        
        messageLabel.setText("Message:");
        mainWindow.getContentPane().add(messageLabel);
        messageLabel.setBounds(10, 10, 60, 20);
              
        messageTF.setForeground(Color.black);
        messageTF.requestFocus();
        mainWindow.getContentPane().add(messageTF);
        messageTF.setBounds(70, 4, 260, 30);
        
        conversationLabel.setHorizontalAlignment(SwingConstants.CENTER);
        conversationLabel.setText("Conversation");
        mainWindow.getContentPane().add(conversationLabel);
        conversationLabel.setBounds(100, 70, 140, 16);
        
        conversationTA.setColumns(20);
        conversationTA.setFont(new java.awt.Font("Tahoma", 0, 12));
        conversationTA.setForeground(Color.black);
        conversationTA.setLineWrap(true);
        conversationTA.setRows(5);
        conversationTA.setEditable(false);
        
        conversationSP.setHorizontalScrollBarPolicy(
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        conversationSP.setVerticalScrollBarPolicy(
                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        conversationSP.setViewportView(conversationTA);
        mainWindow.getContentPane().add(conversationSP);
        conversationSP.setBounds(10, 90, 330, 180);
        
        onlineLabel.setHorizontalAlignment(SwingConstants.CENTER);
        onlineLabel.setText("Currently Online");
        onlineLabel.setToolTipText("");
        mainWindow.getContentPane().add(onlineLabel);
        onlineLabel.setBounds(350, 70, 130, 16);
        
        onlineList.setForeground(Color.black);
        
        onlineSP.setHorizontalScrollBarPolicy(
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        onlineSP.setVerticalScrollBarPolicy(
                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        onlineSP.setViewportView(onlineList);
        mainWindow.getContentPane().add(onlineSP);
        onlineSP.setBounds(350, 90, 130, 180);
        
        loggedInAsLabel.setFont(new java.awt.Font("Tahoma", 0, 12));
        loggedInAsLabel.setText("Currently Logged in As:");
        mainWindow.getContentPane().add(loggedInAsLabel);
        loggedInAsLabel.setBounds(348, 0, 140, 15);
        
        
        loggedInAsBox.setHorizontalAlignment(SwingConstants.CENTER);
        loggedInAsBox.setFont(new java.awt.Font("Tahoma", 0, 12));
        loggedInAsBox.setForeground(Color.red);
        loggedInAsBox.setBorder(
        BorderFactory.createLineBorder(Color.black));
        mainWindow.getContentPane().add(loggedInAsBox);
        loggedInAsBox.setBounds(340, 17, 150, 20);                
    }
    
    /**
     * A method which disables and enables buttons on application launch.
     */
    public static void initialize() {
        sendButton.setEnabled(false);
        disconnectButton.setEnabled(false);
        connectButton.setEnabled(true);
    }
    
    
    
    public static void ipAddressAction(){
        enterButtonIP.addActionListener(
        new java.awt.event.ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                enterIPAction();
            }
        });
    }
    
    
    public static void enterIPAction() {
        hostInput = ipAddressTF.getText().trim();
        ipAddressWindow.setVisible(false);
        connect();
        
    }
    
    /**
     * A method which attaches an action to the login button.
     */
    public static void loginAction() {
        enterButton.addActionListener(
        new java.awt.event.ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                enterAction();
            }
        });
    }
    
    /**
     * A method which prepares the GUI upon user login. Sets user name, adds
     * user name to current users as well as enables buttons used for chatting.
     */
    public static void enterAction() {
        System.out.println("got to enterAction");
        if (!userNameTF.getText().equals("")) {
            System.out.println("got inside !usernameTF");
            
            Connection  myConn;
            Statement   myStmt;
            ResultSet   myRslt;
            Student tempStudent = new Student();
        
        try {
            //1. Get a Connection to database
            myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/login", "root", "23Secondsleft");
            System.out.println("connected to database");
            //2. Create a statement
            myStmt = myConn.createStatement();
            
            //3. Execute SQL query
            myRslt = myStmt.executeQuery("SELECT * FROM login_information");
            System.out.println("selected all from login table");
            //4. Process the result set
            while(myRslt.next()){
                if(userNameTF.getText().trim().equals(myRslt.getInt(1)) && passwordTF.getText().trim().equals(myRslt.getString(2))){
                    tempStudent.setId(myRslt.getInt(1));
                    tempStudent.setPassword(myRslt.getString(2));
                    tempStudent.setFirstName(myRslt.getString(3));
                 
                }
            }
    
        }   catch (Exception exc){
                exc.printStackTrace();
            }
                    
                   System.out.println("outside myRslt");
                   System.out.println(tempStudent.getFirstName() + tempStudent.getId() + tempStudent.getPassword());
                   
                        //userName = userNameTF.getText().trim();
                        userName = tempStudent.getFirstName();
                        loggedInAsBox.setText(userName);
                        ChatServer.currentUsers.add(userName);
                        mainWindow.setTitle(userName + "'s Chat Box");
                        logInWindow.setVisible(false);
                        sendButton.setEnabled(true);
                        disconnectButton.setEnabled(true);
                        connectButton.setEnabled(false); 
                    
                }
                else {
                    JOptionPane.showMessageDialog(null, "Please enter your ID and Password!");
                }                    
            }    
    
    /**
     * A method which attaches all action events to their respective buttons.
     */
    public static void mainWindowActions() {
        sendButton.addActionListener(
        new java.awt.event.ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                sendAction();
            }
        });
        
        disconnectButton.addActionListener(
        new java.awt.event.ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                disconnectAction();
            }
        });
        
        connectButton.addActionListener(
        new java.awt.event.ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                connectToServerAction();
                connectAction();
            }
        });
        
        helpButton.addActionListener(
        new java.awt.event.ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                helpAction();
            }
        });
        
        aboutButton.addActionListener(
        new java.awt.event.ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                aboutAction();
            }
        });
    }
    
    /**
     * An action event which sends a message from a user.
     */
    public static void sendAction() {
        if(!messageTF.getText().equals("")) {
            chatClient.send(messageTF.getText());
            messageTF.requestFocus();
        }
    }
    
    /**
     * An action event which disconnects the user.
     */
    public static void disconnectAction() {
        try {
            chatClient.disconnect();
        }
        catch (Exception e) {
            System.out.println(userName + "has disconnected.");
        }
    }
    
    /**
     * An action event which connects the user.
     */
    public static void connectAction() {
        logInWindow.setTitle("Sign In");
        logInWindow.setSize(400, 130);
        logInWindow.setLocation(250, 200);
        logInWindow.setResizable(false);
        logInPanel = new JPanel();
        logInPanel.add(enterUserLabel);
        logInPanel.add(userNameTF);
        logInPanel.add(enterPasswdLabel);
        logInPanel.add(passwordTF);
        logInPanel.add(enterButton);
        logInWindow.add(logInPanel);
        
        loginAction();
        logInWindow.setVisible(true);        
    }
    
    public static void connectToServerAction(){
      
        ipAddressWindow.setTitle("Host ip address");
        ipAddressWindow.setSize(400, 100);
        ipAddressWindow.setLocation(250, 200);
        ipAddressWindow.setResizable(false);
        ipAddressPanel = new JPanel();
        ipAddressPanel.add(enterIPAddress);
        ipAddressPanel.add(ipAddressTF);
        ipAddressPanel.add(enterButtonIP);
        ipAddressWindow.add(ipAddressPanel);
        
        ipAddressAction();
        ipAddressWindow.setVisible(true);
    }
    
    /**
     * An action event which helps the user.
     */
    public static void helpAction() {
        JOptionPane.showMessageDialog(null,
                "VaqChat v1.0");
    }
    
    /**
     * An action event which displays information about the application.
     */
    public static void aboutAction() {
        JOptionPane.showMessageDialog(null,
                "VaqChat v1.0");
    }
    
    /**
     * A method which attempts to connect the client socket to the server socket
     * to begin communication.
     */
    public static void connect() {
        try {
            final int port = 1337;
            final String host = getHostInput();
            Socket socket = new Socket(host, port);
            System.out.println("You connected to: " + host);
            
            chatClient = new VChat_ClientController(socket);
            
            PrintWriter output = new PrintWriter(socket.getOutputStream());
            output.println(userName);
            output.flush();
            
            Thread t = new Thread(chatClient);
            t.start();
            
        } catch(Exception e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Server not responding...");
            System.exit(0);
        }
    }

    /**
     * @return the chatClient
     */
    public static VChat_ClientController getChatClient() {
        return chatClient;
    }

    /**
     * @param aChatClient the chatClient to set
     */
    public static void setChatClient(VChat_ClientController aChatClient) {
        chatClient = aChatClient;
    }

    /**
     * @return the userName
     */
    public static String getUserName() {
        return userName;
    }

    /**
     * @param aUserName the userName to set
     */
    public static void setUserName(String aUserName) {
        userName = aUserName;
    }

    /**
     * @return the mainWindow
     */
    public static JFrame getMainWindow() {
        return mainWindow;
    }

    /**
     * @param aMainWindow the mainWindow to set
     */
    public static void setMainWindow(JFrame aMainWindow) {
        mainWindow = aMainWindow;
    }

    /**
     * @return the aboutButton
     */
    public static JButton getAboutButton() {
        return aboutButton;
    }

    /**
     * @param aAboutButton the aboutButton to set
     */
    public static void setAboutButton(JButton aAboutButton) {
        aboutButton = aAboutButton;
    }

    /**
     * @return the connectButton
     */
    public static JButton getConnectButton() {
        return connectButton;
    }

    /**
     * @param aConnectButton the connectButton to set
     */
    public static void setConnectButton(JButton aConnectButton) {
        connectButton = aConnectButton;
    }

    /**
     * @return the disconnectButton
     */
    public static JButton getDisconnectButton() {
        return disconnectButton;
    }

    /**
     * @param aDisconnectButton the disconnectButton to set
     */
    public static void setDisconnectButton(JButton aDisconnectButton) {
        disconnectButton = aDisconnectButton;
    }

    /**
     * @return the helpButton
     */
    public static JButton getHelpButton() {
        return helpButton;
    }

    /**
     * @param aHelpButton the helpButton to set
     */
    public static void setHelpButton(JButton aHelpButton) {
        helpButton = aHelpButton;
    }

    /**
     * @return the sendButton
     */
    public static JButton getSendButton() {
        return sendButton;
    }

    /**
     * @param aSendButton the sendButton to set
     */
    public static void setSendButton(JButton aSendButton) {
        sendButton = aSendButton;
    }

    /**
     * @return the messageLabel
     */
    public static JLabel getMessageLabel() {
        return messageLabel;
    }

    /**
     * @param aMessageLabel the messageLabel to set
     */
    public static void setMessageLabel(JLabel aMessageLabel) {
        messageLabel = aMessageLabel;
    }

    /**
     * @return the messageTF
     */
    public static JTextField getMessageTF() {
        return messageTF;
    }

    /**
     * @param aMessageTF the messageTF to set
     */
    public static void setMessageTF(JTextField aMessageTF) {
        messageTF = aMessageTF;
    }

    /**
     * @return the conversationLabel
     */
    public static JLabel getConversationLabel() {
        return conversationLabel;
    }

    /**
     * @param aConversationLabel the conversationLabel to set
     */
    public static void setConversationLabel(JLabel aConversationLabel) {
        conversationLabel = aConversationLabel;
    }

    /**
     * @return the conversationTA
     */
    public static JTextArea getConversationTA() {
        return conversationTA;
    }

    /**
     * @param aConversationTA the conversationTA to set
     */
    public static void setConversationTA(JTextArea aConversationTA) {
        conversationTA = aConversationTA;
    }

    /**
     * @return the conversationSP
     */
    public static JScrollPane getConversationSP() {
        return conversationSP;
    }

    /**
     * @param aConversationSP the conversationSP to set
     */
    public static void setConversationSP(JScrollPane aConversationSP) {
        conversationSP = aConversationSP;
    }

    /**
     * @return the onlineLabel
     */
    public static JLabel getOnlineLabel() {
        return onlineLabel;
    }

    /**
     * @param aOnlineLabel the onlineLabel to set
     */
    public static void setOnlineLabel(JLabel aOnlineLabel) {
        onlineLabel = aOnlineLabel;
    }

    /**
     * @return the onlineList
     */
    public static JList getOnlineList() {
        return onlineList;
    }

    /**
     * @param aOnlineList the onlineList to set
     */
    public static void setOnlineList(JList aOnlineList) {
        onlineList = aOnlineList;
    }

    /**
     * @return the onlineSP
     */
    public static JScrollPane getOnlineSP() {
        return onlineSP;
    }

    /**
     * @param aOnlineSP the onlineSP to set
     */
    public static void setOnlineSP(JScrollPane aOnlineSP) {
        onlineSP = aOnlineSP;
    }

    /**
     * @return the loggedInAsLabel
     */
    public static JLabel getLoggedInAsLabel() {
        return loggedInAsLabel;
    }

    /**
     * @param aLoggedInAsLabel the loggedInAsLabel to set
     */
    public static void setLoggedInAsLabel(JLabel aLoggedInAsLabel) {
        loggedInAsLabel = aLoggedInAsLabel;
    }

    /**
     * @return the loggedInAsBox
     */
    public static JLabel getLoggedInAsBox() {
        return loggedInAsBox;
    }

    /**
     * @param aLoggedInAsBox the loggedInAsBox to set
     */
    public static void setLoggedInAsBox(JLabel aLoggedInAsBox) {
        loggedInAsBox = aLoggedInAsBox;
    }

    /**
     * @return the logInWindow
     */
    public static JFrame getLogInWindow() {
        return logInWindow;
    }

    /**
     * @param aLogInWindow the logInWindow to set
     */
    public static void setLogInWindow(JFrame aLogInWindow) {
        logInWindow = aLogInWindow;
    }

    /**
     * @return the userNameTF
     */
    public static JTextField getUserNameTF() {
        return userNameTF;
    }

    /**
     * @param aUserNameTF the userNameTF to set
     */
    public static void setUserNameTF(JTextField aUserNameTF) {
        userNameTF = aUserNameTF;
    }

    /**
     * @return the enterButton
     */
    public static JButton getEnterButton() {
        return enterButton;
    }

    /**
     * @param aEnterButton the enterButton to set
     */
    public static void setEnterButton(JButton aEnterButton) {
        enterButton = aEnterButton;
    }

    /**
     * @return the enterUserLabel
     */
    public static JLabel getEnterUserLabel() {
        return enterUserLabel;
    }

    /**
     * @param aEnterUserLabel the enterUserLabel to set
     */
    public static void setEnterUserLabel(JLabel aEnterUserLabel) {
        enterUserLabel = aEnterUserLabel;
    }

    /**
     * @return the logInPanel
     */
    public static JPanel getLogInPanel() {
        return logInPanel;
    }

    /**
     * @param aLogInPanel the logInPanel to set
     */
    public static void setLogInPanel(JPanel aLogInPanel) {
        logInPanel = aLogInPanel;
    }

    /**
     * @return the ipAddressWindow
     */
    public static JFrame getIpAddressWindow() {
        return ipAddressWindow;
    }

    /**
     * @param aIpAddressWindow the ipAddressWindow to set
     */
    public static void setIpAddressWindow(JFrame aIpAddressWindow) {
        ipAddressWindow = aIpAddressWindow;
    }

    /**
     * @return the enterIPAddress
     */
    public static JLabel getEnterIPAddress() {
        return enterIPAddress;
    }

    /**
     * @param aEnterIPAddress the enterIPAddress to set
     */
    public static void setEnterIPAddress(JLabel aEnterIPAddress) {
        enterIPAddress = aEnterIPAddress;
    }

    /**
     * @return the ipAddressTF
     */
    public static JTextField getIpAddressTF() {
        return ipAddressTF;
    }

    /**
     * @param aIpAddressTF the ipAddressTF to set
     */
    public static void setIpAddressTF(JTextField aIpAddressTF) {
        ipAddressTF = aIpAddressTF;
    }

    /**
     * @return the enterButtonIP
     */
    public static JButton getEnterButtonIP() {
        return enterButtonIP;
    }

    /**
     * @param aEnterButtonIP the enterButtonIP to set
     */
    public static void setEnterButtonIP(JButton aEnterButtonIP) {
        enterButtonIP = aEnterButtonIP;
    }

    /**
     * @return the ipAddressPanel
     */
    public static JPanel getIpAddressPanel() {
        return ipAddressPanel;
    }

    /**
     * @param aIpAddressPanel the ipAddressPanel to set
     */
    public static void setIpAddressPanel(JPanel aIpAddressPanel) {
        ipAddressPanel = aIpAddressPanel;
    }

    /**
     * @return the hostInput
     */
    public static String getHostInput() {
        return hostInput;
    }

    /**
     * @param aHostInput the hostInput to set
     */
    public static void setHostInput(String aHostInput) {
        hostInput = aHostInput;
    }
}
