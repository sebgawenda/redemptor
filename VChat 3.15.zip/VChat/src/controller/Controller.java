/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.io.PrintWriter;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;
import student.Student;
import view.*;
import vchat_client.*;
//import controller.Singleton.getInstance();


/**
 *
 * @author srv_veralab
 */
public class Controller {
    
    private static SignIn signIn = new SignIn();
    private static CreateAccount createAccount = new CreateAccount();
    private static Chatroom chatroom = new Chatroom();
    private static VchatClient client = new VchatClient();    
    private static Stage stage = new Stage();
    private int count = 0;

    
    
    
    public Controller(SignIn signIn, CreateAccount createAccount, Chatroom chatroom, VchatClient client) {
        this.signIn = signIn;
        this.createAccount = createAccount;
        this.chatroom = chatroom;
        this.client = client;
        attachHandlers();

        
    }
    
    public void attachHandlers(){
        
        
        
        getSignIn().getLoginBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                /**
                * TODO
                * Gather information from login text field (here)
                * Connect to the Server thru the client (client)
                * Send student's id and password to the server (client)
                * Receive authentication from the server (client)
                *      if yes: goToChatroomStage
                *      if no: Dialog Box: "Wrong username or password"
                */

                System.out.println("Start Controller Login Button");
                System.out.println("ok");
                
                
                System.out.println("test " +signIn.getIpTF().getText().trim());
                
               
               String id = "";
               String password = "";
               String ipAddress = "";

               
               id = signIn.getIdTF().getText();
               System.out.println("id is " + id);
               
               password = signIn.getPasswordTF().getText().trim();
               System.out.println(password);
 /*              
               Singleton clientInfo = new Singleton();
               clientInfo.setId(id);
               clientInfo.setPassword(password);
 */          
            //   Student student = new Student(id, password);
               
               //connected to server
               ipAddress = signIn.getIpTF().getText().trim();
               System.out.println("ipAddress is " + ipAddress);
               client.connect(ipAddress, id, password);
               
               
                System.out.println("End Controller Login button");
               
            }	
        });
        
        getSignIn().getCreateAccountBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                
                //WORKING CODE
                getSignIn().getScene().getWindow().hide();      
                if (count == 0){
                    Scene scene = new Scene(createAccount, 400,400);
                    stage.setScene(scene);
                    stage.setTitle("Sign-Up");
                    stage.setResizable(false);
                    stage.show();
                    count++;
                }else if(count > 0){
                    stage.setScene(getCreateAccount().getScene());
                    stage.setTitle("Sign-Up");
                    stage.setResizable(false);
                    stage.show();
                }
              
                /*
                //BROKEN CODE
                Singleton.getStage().setScene(getCreateAccount().getScene());
                Singleton.getCaScene();
                Singleton.getStage().setTitle("Sign-Up");
                Singleton.getStage().setScene(Singleton.getCaScene());
                Singleton.getStage().show();
                Singleton.getStage().setResizable(false);
                
                        
                Pane createAccountPane = (Pane) createAccount;
                stage.setScene(getCreateAccount().getScene());
                Scene scene2 = new Scene(createAccount, 400, 400); 
                stage.setTitle("Register");
                stage.setScene(scene2);
                stage.show();    
                stage.setResizable(false);
                */
            }    	
        });
        
        getCreateAccount().getCreateAccountBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                /**
                 * TODO
                 * 
                 */
               
                System.out.println("pressing Create Account button");

            }    	
        });
        
        getCreateAccount().getBackBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                //WORKING CODE
                getCreateAccount().getScene().getWindow().hide();
                stage.setScene(getSignIn().getScene());
                stage.setTitle("Sign-In");
                stage.setResizable(false);
                stage.show();
                
            }    	
        });
        
    }

    /**
     * @return the signIn
     */
    public static SignIn getSignIn() {
        return signIn;
    }

    /**
     * @return the createAccount
     */
    public static CreateAccount getCreateAccount() {
        return createAccount;
    }

    /**
     * @return the chatroom
     */
    public static Chatroom getChatroom() {
        return chatroom;
    }

    /**
     * @return the client
     */
    public static VchatClient getClient() {
        return client;
    }
    
}  

