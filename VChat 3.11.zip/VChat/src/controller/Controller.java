/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import student.Student;
import view.*;
import vchat_client.*;
import vchat_server.*;


/**
 *
 * @author srv_veralab
 */
public class Controller {
    
    SignIn signIn;
    CreateAccount createAccount;
    Chatroom chatroom;
    VchatClient client;
    ChatServer server;

    public Controller(SignIn signIn, CreateAccount createAccount, Chatroom chatroom, VchatClient client) {
        this.signIn = signIn;
        this.createAccount = createAccount;
        this.chatroom = chatroom;
        this.client = client;
        //this.server = server;
        attachHandlers();
    }
    
    public void attachHandlers(){
       
        signIn.getLoginBtn().setOnAction(
			new EventHandler<ActionEvent>()
			{
			@Override
			public void handle(ActionEvent event) 
			{
                            
                            String id;
                           
                            String password;
                            String ipAddress;
                            
                            Student student = new Student();
                            id = signIn.getIdTF().getText().trim();
                            password = signIn.getPasswordTF().getText().trim();
                            ipAddress = signIn.getIpTF().getText().trim();
                            
                            
                            student.setId(id);
                            student.setPassword(password);
                     
                            client.connect(ipAddress);
                            
				
			}
				
			}

		);
    }
    
    
    
    
    
}
