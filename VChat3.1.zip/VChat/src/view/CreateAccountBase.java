
package view;

import javafx.collections.FXCollections;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;

public abstract class CreateAccountBase extends Pane {

    protected final Label fNameLabel;
    protected final Label lNameLable;
    protected final Label majorLabel;
    protected final Label emailLabel;
    protected final Label idLabel;
    protected final Label passwordLabel;
    protected final TextField fNameTF;
    protected final TextField lNameTF;
    protected final TextField emailTF;
    protected final TextField idTF;
    protected final PasswordField passwordTF;
 //   protected final ComboBox majorCB;
  //  protected final FXCollections fXCollections;
    protected final Button createAccountBtn;
    protected final DropShadow dropShadow;
    protected final Button backBtn;

    public CreateAccountBase() {

        fNameLabel = new Label();
        lNameLable = new Label();
        majorLabel = new Label();
        emailLabel = new Label();
        idLabel = new Label();
        passwordLabel = new Label();
        fNameTF = new TextField();
        lNameTF = new TextField();
        emailTF = new TextField();
        idTF = new TextField();
        passwordTF = new PasswordField();
    //    majorCB = new ComboBox();
//        fXCollections = new FXCollections();
        createAccountBtn = new Button();
        dropShadow = new DropShadow();
        backBtn = new Button();

        setFocusTraversable(true);
        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(450.0);
        setPrefWidth(430.0);

        fNameLabel.setLayoutX(30.0);
        fNameLabel.setLayoutY(100.0);
        fNameLabel.setText("First Name:");
        fNameLabel.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        fNameLabel.setFont(new Font(18.0));

        lNameLable.setLayoutX(32.0);
        lNameLable.setLayoutY(140.0);
        lNameLable.setText("Last Name:");
        lNameLable.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        lNameLable.setFont(new Font(18.0));

        majorLabel.setLayoutX(72.0);
        majorLabel.setLayoutY(299.0);
        majorLabel.setText("Major:");
        majorLabel.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        majorLabel.setFont(new Font(18.0));

        emailLabel.setAlignment(javafx.geometry.Pos.CENTER_RIGHT);
        emailLabel.setLayoutX(74.0);
        emailLabel.setLayoutY(180.0);
        emailLabel.setText("Email:");
        emailLabel.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        emailLabel.setFont(new Font(18.0));

        idLabel.setLayoutX(100.0);
        idLabel.setLayoutY(220.0);
        idLabel.setPrefHeight(27.0);
        idLabel.setPrefWidth(26.0);
        idLabel.setText("ID:");
        idLabel.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        idLabel.setFont(new Font(18.0));

        passwordLabel.setLayoutX(43.0);
        passwordLabel.setLayoutY(260.0);
        passwordLabel.setText("Password:");
        passwordLabel.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        passwordLabel.setFont(new Font(18.0));

        fNameTF.setLayoutX(125.0);
        fNameTF.setLayoutY(100.0);
        fNameTF.setPrefHeight(27.0);
        fNameTF.setPrefWidth(200.0);
        fNameTF.setPromptText("enter First Name");

        lNameTF.setLayoutX(125.0);
        lNameTF.setLayoutY(138.0);
        lNameTF.setPrefHeight(27.0);
        lNameTF.setPrefWidth(200.0);
        lNameTF.setPromptText("enter Last Name");

        emailTF.setLayoutX(125.0);
        emailTF.setLayoutY(180.0);
        emailTF.setPrefHeight(27.0);
        emailTF.setPrefWidth(200.0);
        emailTF.setPromptText("enter Student Email");

        idTF.setLayoutX(125.0);
        idTF.setLayoutY(220.0);
        idTF.setPrefHeight(27.0);
        idTF.setPrefWidth(200.0);
        idTF.setPromptText("enter Student ID");

        passwordTF.setLayoutX(125.0);
        passwordTF.setLayoutY(260.0);
        passwordTF.setPrefHeight(27.0);
        passwordTF.setPrefWidth(200.0);
        passwordTF.setPromptText("enter Password");

  //      majorCB.setLayoutX(126.0);
  //      majorCB.setLayoutY(300.0);
   //     majorCB.setPrefHeight(25.0);
    //    majorCB.setPrefWidth(200.0);

        createAccountBtn.setDefaultButton(true);
        createAccountBtn.setLayoutX(150.0);
        createAccountBtn.setLayoutY(342.0);
        createAccountBtn.setMnemonicParsing(false);
        createAccountBtn.setOnAction(this::createAccountAction);
        createAccountBtn.setText("Create Account");
        createAccountBtn.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        createAccountBtn.setFont(new Font(18.0));

        createAccountBtn.setEffect(dropShadow);

        backBtn.setCancelButton(true);
        backBtn.setLayoutX(198.0);
        backBtn.setLayoutY(393.0);
        backBtn.setMnemonicParsing(false);
        backBtn.setOnAction(this::goBackAction);
        backBtn.setText("Back");
        backBtn.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        backBtn.setFont(new Font(14.0));

        getChildren().add(fNameLabel);
        getChildren().add(lNameLable);
        getChildren().add(majorLabel);
        getChildren().add(emailLabel);
        getChildren().add(idLabel);
        getChildren().add(passwordLabel);
        getChildren().add(fNameTF);
        getChildren().add(lNameTF);
        getChildren().add(emailTF);
        getChildren().add(idTF);
        getChildren().add(passwordTF);
  //      majorCB.getItems().add(fXCollections);
   //     getChildren().add(majorCB);
        getChildren().add(createAccountBtn);
        getChildren().add(backBtn);

    }

    protected abstract void createAccountAction(javafx.event.ActionEvent actionEvent);

    protected abstract void goBackAction(javafx.event.ActionEvent actionEvent);

}
