package view;

import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;

public class SignInBase extends Pane {

    protected final TextField idTF;
    protected final PasswordField passwordTF;
    protected final Button loginBtn;
    protected final DropShadow dropShadow;
    protected final Button createAccountBtn;
    protected final Label idLabel;
    protected final Label label;
    protected final Hyperlink forgot_pwHL;
    protected final ImageView signinLogo;

    public SignInBase() {

        idTF = new TextField();
        passwordTF = new PasswordField();
        loginBtn = new Button();
        dropShadow = new DropShadow();
        createAccountBtn = new Button();
        idLabel = new Label();
        label = new Label();
        forgot_pwHL = new Hyperlink();
        signinLogo = new ImageView();

        setId("loginPane");
        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(422.0);
        setPrefWidth(432.0);

        idTF.setLayoutX(124.0);
        idTF.setLayoutY(160.0);
        idTF.setPrefHeight(46.0);
        idTF.setPrefWidth(182.0);
        idTF.setPromptText("enter Student ID");

        passwordTF.setLayoutX(126.0);
        passwordTF.setLayoutY(218.0);
       // passwordTF.setOnKeyPressed(this::loginOnEnter);
        passwordTF.setPrefHeight(46.0);
        passwordTF.setPrefWidth(182.0);
        passwordTF.setPromptText("enter Password");

        loginBtn.setContentDisplay(javafx.scene.control.ContentDisplay.CENTER);
        loginBtn.setDefaultButton(true);
        loginBtn.setLayoutX(143.0);
        loginBtn.setLayoutY(280.0);
        loginBtn.setMnemonicParsing(false);
        //loginBtn.setOnAction(this::signIn);
        loginBtn.setPrefHeight(46.0);
        loginBtn.setPrefWidth(147.0);
        loginBtn.setText("Login");
        loginBtn.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        loginBtn.setWrapText(true);
        loginBtn.setFont(new Font("System Bold", 14.0));
        loginBtn.setOpaqueInsets(new Insets(0.0));
        loginBtn.setCursor(Cursor.HAND);

        loginBtn.setEffect(dropShadow);

        createAccountBtn.setLayoutX(143.0);
        createAccountBtn.setLayoutY(334.0);
        createAccountBtn.setMnemonicParsing(false);
        //createAccountBtn.setOnAction(this::createAccount);
        createAccountBtn.setPrefHeight(32.0);
        createAccountBtn.setPrefWidth(147.0);
        createAccountBtn.setText("Create Account");
        createAccountBtn.setCursor(Cursor.HAND);

        idLabel.setLayoutX(56.0);
        idLabel.setLayoutY(175.0);
        idLabel.setText("Student ID:");

        label.setId("passwordLabel");
        label.setLayoutX(62.0);
        label.setLayoutY(232.0);
        label.setText("Password:");

        forgot_pwHL.setLayoutX(188.0);
        forgot_pwHL.setLayoutY(372.0);
        forgot_pwHL.setText("Forgot Password?");
        forgot_pwHL.setUnderline(true);

        signinLogo.setFitHeight(100.0);
        signinLogo.setFitWidth(225.0);
        signinLogo.setLayoutX(115.0);
        signinLogo.setLayoutY(46.0);
        signinLogo.setPickOnBounds(true);
        signinLogo.setPreserveRatio(true);
        signinLogo.setImage(new Image(getClass().getResource("VChat_splash.png").toExternalForm()));

        getChildren().add(idTF);
        getChildren().add(passwordTF);
        getChildren().add(loginBtn);
        getChildren().add(createAccountBtn);
        getChildren().add(idLabel);
        getChildren().add(label);
        getChildren().add(forgot_pwHL);
        getChildren().add(signinLogo);

    }

//    protected abstract void loginOnEnter(javafx.scene.input.KeyEvent keyEvent);
//
//    protected abstract void signIn(javafx.event.ActionEvent actionEvent);
//
//    protected abstract void createAccount(javafx.event.ActionEvent actionEvent);

}
