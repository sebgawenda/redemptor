/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vchat_client;

import java.io.PrintWriter;
import java.net.Socket;
import controller.Singleton;
import javafx.scene.control.ListView;

/**
 *
 * @author srv_veralab
 */
public class VchatClient {
    
    private static VchatClientController chatClient;
    private static String fName =  Singleton.getInstance().getfName().toString();
    private static String lName = Singleton.getInstance().getlName().toString();
    private static String email = Singleton.getInstance().getEmail().toString();
    private static String id = Singleton.getInstance().getId().toString();
    private static String password = Singleton.getInstance().getPassword().toString();
    private static String major = Singleton.getInstance().getMajor().toString();
    private ListView onlineList = new ListView();


    public static void connect() {
        try {
            final int port = 1337;
            final String host = "172.16.41.56";
            Socket socket = new Socket(host, port);
            System.out.println("You connected to: " + host);
            
            setChatClient(new VchatClientController(socket));
            
            PrintWriter output = new PrintWriter(socket.getOutputStream());
            output.println(getfName() + " " + getlName());
            output.flush();
            
            Thread t = new Thread((Runnable) getChatClient());
            t.start();
            
        } catch(Exception e) {
            System.out.println(e);
            System.out.println("Server not responding...");
            //JOptionPane.showMessageDialog(null, "Server not responding.");
            System.exit(0);
        }
    }

    /**
     * @return the chatClient
     */
    public static VchatClientController getChatClient() {
        return chatClient;
    }

    /**
     * @param aChatClient the chatClient to set
     */
    public static void setChatClient(VchatClientController aChatClient) {
        chatClient = aChatClient;
    }

    /**
     * @return the fName
     */
    public static String getfName() {
        return fName;
    }

    /**
     * @param afName the fName to set
     */
    public static void setfName(String afName) {
        fName = afName;
    }

    /**
     * @return the lName
     */
    public static String getlName() {
        return lName;
    }

    /**
     * @param alName the lName to set
     */
    public static void setlName(String alName) {
        lName = alName;
    }

    /**
     * @return the email
     */
    public static String getEmail() {
        return email;
    }

    /**
     * @param aEmail the email to set
     */
    public static void setEmail(String aEmail) {
        email = aEmail;
    }

    /**
     * @return the id
     */
    public static String getId() {
        return id;
    }

    /**
     * @param aId the id to set
     */
    public static void setId(String aId) {
        id = aId;
    }

    /**
     * @return the password
     */
    public static String getPassword() {
        return password;
    }

    /**
     * @param aPassword the password to set
     */
    public static void setPassword(String aPassword) {
        password = aPassword;
    }

    /**
     * @return the major
     */
    public static String getMajor() {
        return major;
    }

    /**
     * @param aMajor the major to set
     */
    public static void setMajor(String aMajor) {
        major = aMajor;
    }

    /**
     * @return the onlineList
     */
    public ListView getOnlineList() {
        return onlineList;
    }

    /**
     * @param onlineList the onlineList to set
     */
    public void setOnlineList(ListView onlineList) {
        this.onlineList = onlineList;
    }
    
}
