/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 *
 * @author arman
 */
public class StageFunctions{
    
    public void setStage(String name, String title){
        try{
            Stage chatroom = new Stage();
            Pane root = (Pane) FXMLLoader.load(getClass().getResource("/view/"+name+".fxml"));
            Scene scene = new Scene(root);
            chatroom.setScene(scene);
            chatroom.setTitle(title);
            chatroom.show();
            chatroom.setResizable(false);    
        } catch(Exception e){
            e.printStackTrace();      
        }
    }
    
}
