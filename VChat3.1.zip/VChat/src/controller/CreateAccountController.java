/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.DBHandler;
import student.Student;

/**
 * FXML Controller class
 *
 * @author arman
 */
public class CreateAccountController extends StageFunctions implements Initializable {

    @FXML
    private Pane createAccountPane;
    @FXML
    private Label fNameLabel;
    @FXML
    private Label majorLabel;
    @FXML
    private Label emailLabel;
    @FXML
    private TextField fNameTF;
    @FXML
    private TextField lNameTF;
    @FXML
    private TextField emailTF;
    @FXML
    private ComboBox<?> majorCB;
    @FXML
    private Button createAccountBtn;
    @FXML
    private Label lNameLable;
    @FXML
    private Label idLabel;
    @FXML
    private TextField idTF;
    @FXML
    private PasswordField passwordTF;
    @FXML
    private Label passwordLabel;
    @FXML
    private Button backBtn;
    
    private Connection conn;
    private DBHandler handler;
    private PreparedStatement pst;
    
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        setHandler(new DBHandler());
        
    }    

    @FXML
    private void createAccountAction(ActionEvent event) {
        
        //Creates an object of class Student
        Student newStudent = new Student();
        
        //Pass in text field information into the student object
        newStudent.setId(getIdTF().getText().trim());
        newStudent.setFirstName(getfNameTF().getText().trim());
        newStudent.setLastName(getlNameTF().getText().trim());
        newStudent.setPassword(getPasswordTF().getText().trim());
        newStudent.setEmail(getEmailTF().getText().trim());
        newStudent.setMajor(getMajorCB().getSelectionModel().getSelectedItem().toString());
                
        
        
        //Saving Data
        String insert = "INSERT INTO students(ID,firstName,lastName,password"
                + ",email,major)VALUES(?,?,?,?,?,?)";
        System.out.println("debug 1");
        
        setConn(getHandler().getConnection());
        try{
            
            System.out.println("debug 2");
            setPst(getConn().prepareStatement(insert));         
            System.out.println("debug 2.1");
        } catch (SQLException e1){
            
            System.out.println("debug 3");
            //e1.printStackTrace();
        }
        
        try{
            
            System.out.println("debug 4");
            getPst().setString(1, newStudent.getId());
            getPst().setString(2, newStudent.getFirstName());
            getPst().setString(3, newStudent.getLastName());
            getPst().setString(4, newStudent.getPassword());
            getPst().setString(5, newStudent.getEmail());
            getPst().setString(6, newStudent.getMajor());
            System.out.println("ready to executeUpdate...");
            getPst().executeUpdate();
            System.out.println("Past executeUpdate....");
            
        } catch(SQLException e2) {
            e2.printStackTrace();
        }
        
        goToSignInStage();    
    }

    @FXML
    private void goBackAction(ActionEvent event) throws IOException {
        goToSignInStage();   
    }

    
    private void goToSignInStage(){
        setStage("SignIn", "Sign In");
    }
    
    
    /**
     * @return the fNameTF
     */
    public TextField getfNameTF() {
        return fNameTF;
    }

    /**
     * @return the idTF
     */
    public TextField getIdTF() {
        return idTF;
    }

    /**
     * @return the passwordTF
     */
    public PasswordField getPasswordTF() {
        return passwordTF;
    }

    /**
     * @return the createAccountPane
     */
    public Pane getCreateAccountPane() {
        return createAccountPane;
    }

    /**
     * @param createAccountPane the createAccountPane to set
     */
    public void setCreateAccountPane(Pane createAccountPane) {
        this.createAccountPane = createAccountPane;
    }

    /**
     * @return the fNameLabel
     */
    public Label getfNameLabel() {
        return fNameLabel;
    }

    /**
     * @param fNameLabel the fNameLabel to set
     */
    public void setfNameLabel(Label fNameLabel) {
        this.fNameLabel = fNameLabel;
    }

    /**
     * @return the majorLabel
     */
    public Label getMajorLabel() {
        return majorLabel;
    }

    /**
     * @param majorLabel the majorLabel to set
     */
    public void setMajorLabel(Label majorLabel) {
        this.majorLabel = majorLabel;
    }

    /**
     * @return the emailLabel
     */
    public Label getEmailLabel() {
        return emailLabel;
    }

    /**
     * @param emailLabel the emailLabel to set
     */
    public void setEmailLabel(Label emailLabel) {
        this.emailLabel = emailLabel;
    }

    /**
     * @param fNameTF the fNameTF to set
     */
    public void setfNameTF(TextField fNameTF) {
        this.fNameTF = fNameTF;
    }

    /**
     * @return the lNameTF
     */
    public TextField getlNameTF() {
        return lNameTF;
    }

    /**
     * @param lNameTF the lNameTF to set
     */
    public void setlNameTF(TextField lNameTF) {
        this.lNameTF = lNameTF;
    }

    /**
     * @return the emailTF
     */
    public TextField getEmailTF() {
        return emailTF;
    }

    /**
     * @param emailTF the emailTF to set
     */
    public void setEmailTF(TextField emailTF) {
        this.emailTF = emailTF;
    }

    /**
     * @return the majorCB
     */
    public ComboBox<?> getMajorCB() {
        return majorCB;
    }

    /**
     * @param majorCB the majorCB to set
     */
    public void setMajorCB(ComboBox<?> majorCB) {
        this.majorCB = majorCB;
    }

    /**
     * @return the createAccountBtn
     */
    public Button getCreateAccountBtn() {
        return createAccountBtn;
    }

    /**
     * @param createAccountBtn the createAccountBtn to set
     */
    public void setCreateAccountBtn(Button createAccountBtn) {
        this.createAccountBtn = createAccountBtn;
    }

    /**
     * @return the lNameLable
     */
    public Label getlNameLable() {
        return lNameLable;
    }

    /**
     * @param lNameLable the lNameLable to set
     */
    public void setlNameLable(Label lNameLable) {
        this.lNameLable = lNameLable;
    }

    /**
     * @return the idLabel
     */
    public Label getIdLabel() {
        return idLabel;
    }

    /**
     * @param idLabel the idLabel to set
     */
    public void setIdLabel(Label idLabel) {
        this.idLabel = idLabel;
    }

    /**
     * @param idTF the idTF to set
     */
    public void setIdTF(TextField idTF) {
        this.idTF = idTF;
    }

    /**
     * @param passwordTF the passwordTF to set
     */
    public void setPasswordTF(PasswordField passwordTF) {
        this.passwordTF = passwordTF;
    }

    /**
     * @return the passwordLabel
     */
    public Label getPasswordLabel() {
        return passwordLabel;
    }

    /**
     * @param passwordLabel the passwordLabel to set
     */
    public void setPasswordLabel(Label passwordLabel) {
        this.passwordLabel = passwordLabel;
    }

    /**
     * @return the backBtn
     */
    public Button getBackBtn() {
        return backBtn;
    }

    /**
     * @param backBtn the backBtn to set
     */
    public void setBackBtn(Button backBtn) {
        this.backBtn = backBtn;
    }

    /**
     * @return the conn
     */
    public Connection getConn() {
        return conn;
    }

    /**
     * @param conn the conn to set
     */
    public void setConn(Connection conn) {
        this.conn = conn;
    }

    /**
     * @return the handler
     */
    public DBHandler getHandler() {
        return handler;
    }

    /**
     * @param handler the handler to set
     */
    public void setHandler(DBHandler handler) {
        this.handler = handler;
    }

    /**
     * @return the pst
     */
    public PreparedStatement getPst() {
        return pst;
    }

    /**
     * @param pst the pst to set
     */
    public void setPst(PreparedStatement pst) {
        this.pst = pst;
    }
    
}
