/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Main.Main;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author srv_veralab
 */
public class Controller implements Runnable {
    
    Socket socket;
    Scanner input;
    Scanner send = new Scanner(System.in);
    PrintWriter output;

    public Controller(Socket s) {
        this.socket = s;
    }
    
    @Override
    public void run() {
        try{
            try{
                input = new Scanner(socket.getInputStream());
                output = new PrintWriter(socket.getOutputStream());
                output.flush();
                
                checkStream();
            }
            finally {
                socket.close();
            }
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
   
   /**
    * A method which calls the receive method as long as the client is
    * connected.
    */
    public void checkStream(){
        while (true) {
            receive();
        }
    }
    
   /**
    * A method which waits for client messages and appends them to the
    * conversation.
    */
    public void receive() {
        if (input.hasNext()){
            String message = input.nextLine();
            
            if(message.contains("#?!")){
                String temp = message.substring(3);
                temp = temp.replace("[", "");
                temp = temp.replace("]", "");
                
                String[] currentUsers = temp.split(", ");
                
                Main.onlineList.setListData(currentUsers);
            }
            else {
                Main.chatTA.append(message + "\n");
            }    
        }
    }
    
   /**
    * A method which sends the user's message to the chat.
    * @param s 
    */
    public void send(String s) {
        output.println(Main.userName + ": " + s);
        output.flush();
        
        Main.messageTF.setText("");     
    }
    
   /**
    * A method which disconnects the user from the chat room.
    * @throws IOException 
    */
    public void disconnect() throws IOException {
        output.println(Main.userName + " has disconnected...");
        output.flush();
        
        socket.close();
        
        JOptionPane.showMessageDialog(null, "You Disconnected!");
        System.exit(0);
    } 
}
