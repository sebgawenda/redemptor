public class StudentLogin {
    
    private int ID;
    private String password;
    

    

    public StudentLogin(int ID, String password) {
        this.ID = ID;
        this.password = password;
    }
    
    

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the ID
     */
    public int getID() {
        return ID;
    }

    /**
     * @param ID the ID to set
     */
    public void setID(int ID) {
        this.ID = ID;
    }

   
}
