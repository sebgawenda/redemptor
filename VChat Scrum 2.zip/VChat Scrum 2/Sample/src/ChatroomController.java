/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author srv_veralab
 */
public class ChatroomController implements Initializable {
    @FXML
    private BorderPane chatroomBorderPane;
    @FXML
    private ToolBar chatroomTB;
    @FXML
    private Button joinBtn;
    @FXML
    private Button createBtn;
    @FXML
    private Button helpBtn;
    @FXML
    private Label messageLabel;
    @FXML
    private TextField messageTF;
    @FXML
    private Button attachBtn;
    @FXML
    private Button sendBtn;
    @FXML
    private TextArea chatTA;
    @FXML
    private Label userCRLabel;
    @FXML
    private Label idCRLabel;
    @FXML
    private Label chatroomNameLabel;
    @FXML
    private Label usersConnectedLabel;
    @FXML
    private ListView<?> onlineList;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void joinChatroom(ActionEvent event) {
    }

    @FXML
    private void createChatroom(ActionEvent event) {
    }

    @FXML
    private void helpInfo(ActionEvent event) {
    }

    @FXML
    private void attachFile(ActionEvent event) {
    }

    @FXML
    private void sendMessage(ActionEvent event) {
    }
    
}
