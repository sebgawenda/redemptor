/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import student.Student;
import view.*;
import vchat_client.*;


/**
 *
 * @author srv_veralab
 */
public class Controller {
    
    SignIn signIn;
    CreateAccount createAccount;
    Chatroom chatroom;
    VchatClient client;    
    Stage stage = new Stage();

    
    
    
    public Controller(SignIn signIn, CreateAccount createAccount, Chatroom chatroom, VchatClient client) {
        this.signIn = signIn;
        this.createAccount = createAccount;
        this.chatroom = chatroom;
        this.client = client;
        attachHandlers();

        
    }
    
    public void attachHandlers(){
        
        
        
        signIn.getLoginBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                /**
                * TODO
                * Gather information from login text field (here)
                * Connect to the Server thru the client (client)
                * Send student's id and password to the server (client)
                * Receive authentication from the server (client)
                *      if yes: goToChatroomStage and connect to server
                *      if no: Dialog Box: "Wrong username or password"
                */

               String id = "";
               String password = "";
               String ipAddress = "";

               id = signIn.getIdTF().getText().trim();
               password = signIn.getPasswordTF().getText().trim();
               ipAddress = signIn.getIpTF().getText().trim();

               Student student = new Student(id, password);

               client.connect(ipAddress);
            }	
        });
        
        signIn.getCreateAccountBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                signIn.getScene().getWindow().hide();
//                Pane createAccountPane = (Pane) createAccount;
                
                stage.setScene(createAccount.getScene());
//                Scene scene2 = new Scene(createAccountPane, 400, 400); 
                stage.setTitle("Register");
//                stage.setScene(scene2);
                stage.show();    
                stage.setResizable(false);
            }    	
        });
        
        createAccount.getCreateAccountBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
               
                System.out.println("pressing Create Account button");

            }    	
        });
        
        createAccount.getBackBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                
                createAccount.getScene().getWindow().hide();
                
                
                //Pane signInPane = (Pane) signIn;
                
                
                stage.setScene(signIn.getScene());
                stage.show();
                /*
                Scene scene1 = new Scene(signIn, 432, 460);

                stage.setTitle("Sign-In");
                stage.setScene(scene1);
                stage.show();    
                stage.setResizable(false);
                */
            }    	
        });
        
    }
    
}  

