/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import vchat_client.VchatClient;
import view.Chatroom;
import view.CreateAccount;
import view.SignIn;
import controller.Controller;

/**
 *
 * @author arman
 */
public class Main extends Application {
    
    @Override
    public void start(Stage primaryStage){
        try{
            SignIn signIn = new SignIn();
            CreateAccount createAccount = new CreateAccount();
            Chatroom chatroom = new Chatroom();
            VchatClient client = new VchatClient();
            
            
            System.out.println("before main controller c");
            Controller c = new Controller(signIn, createAccount, chatroom, client);
            System.out.println("after main controller c");
            
            
            Pane root = (Pane) signIn;
            Scene scene = new Scene(root, 432, 460);
            primaryStage.setTitle("Sign-In");
            primaryStage.setScene(scene);
            primaryStage.show();
            primaryStage.setResizable(false);
            
            /*
            Pane pane2 = (Pane) createAccount;
            Stage stage2 = new Stage();
            Scene scene2 = new Scene(pane2, 400, 400);
            stage2.setTitle("Register");
            stage2.setScene(scene2);
            stage2.show();    
            stage2.setResizable(false);
            createAccount.getScene().getWindow().hide();
            */
            
            
        }catch (Exception e) {
            e.printStackTrace();
        }
                
        
        
    }
    
    public static void main(String[] args){
        launch(args);
    }
    
}
