/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vchat_client;

import java.io.PrintWriter;
import java.net.Socket;
import controller.Singleton;
import javafx.scene.control.ListView;

/**
 *
 * @author srv_veralab
 */
public class VchatClient {
    
    private static VchatClientController chatClient;
    
    private String host = "";
    /*
    private static String fName =  Singleton.getInstance().getfName().toString();
    private static String lName = Singleton.getInstance().getlName().toString();
    private static String email = Singleton.getInstance().getEmail().toString();
    private static String id = Singleton.getInstance().getId().toString();
    private static String password = Singleton.getInstance().getPassword().toString();
    private static String major = Singleton.getInstance().getMajor().toString();
    private ListView onlineList = new ListView();
    */


    public void connect(String host) {
        try {
            final int port = 1337;
         
            Socket socket = new Socket(host, port);
            System.out.println("You connected to: " + host);
            /*
            setChatClient(new VchatClientController(socket));
            
            PrintWriter output = new PrintWriter(socket.getOutputStream());
//            output.println(getfName() + " " + getlName());
            output.flush();
            
            Thread t = new Thread((Runnable) getChatClient());
            t.start();
            */
            
        } catch(Exception e) {
            System.out.println(e);
            System.out.println("Server not responding...");
            //JOptionPane.showMessageDialog(null, "Server not responding.");
            System.exit(0);
        }
    }

    /**
     * @return the chatClient
     */
    public static VchatClientController getChatClient() {
        return chatClient;
    }

    /**
     * @param aChatClient the chatClient to set
     */
    public static void setChatClient(VchatClientController aChatClient) {
        chatClient = aChatClient;
    }

   
    /**
     * @return the host
     */
    public String getHost() {
        return host;
    }

    /**
     * @param host the host to set
     */
    public void setHost(String host) {
        this.host = host;
    }
    
}
