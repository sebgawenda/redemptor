/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


/**
 *
 * @author arman
 */
public class Singleton {
    
    private static Singleton instance = new Singleton();
    public static Singleton getInstance(){
        return instance;
    }
    
    //Login/Create Account Window
    private TextField fName;
    private TextField lName;
    private TextField email;
    private TextField id;
    private TextField password;
    
    //Chatroom Window
    private TextArea chatTA;
    private ListView onlineList;
    
    //Scenes
    private static Stage stage = new Stage();
    
    //Login Scene
    private static Pane signInPane = (Pane) Controller.getSignIn();
    private static Scene signInScene = new Scene(signInPane, 432, 460);
    
    //Create Account Scene
    private static Pane createAccountPane = (Pane) Controller.getCreateAccount();
    private static Scene caScene = new Scene(createAccountPane, 400, 400);
    
    //Chatroom Scene
                

    /**
     * @param aInstance the instance to set
     */
    public static void setInstance(Singleton aInstance) {
        instance = aInstance;
    }

    /**
     * @return the fName
     */
    public TextField getfName() {
        return fName;
    }

    /**
     * @param fName the fName to set
     */
    public void setfName(TextField fName) {
        this.fName = fName;
    }

    /**
     * @return the lName
     */
    public TextField getlName() {
        return lName;
    }

    /**
     * @param lName the lName to set
     */
    public void setlName(TextField lName) {
        this.lName = lName;
    }

    /**
     * @return the email
     */
    public TextField getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(TextField email) {
        this.email = email;
    }

    /**
     * @return the id
     */
    public TextField getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(TextField id) {
        this.id = id;
    }

    /**
     * @return the password
     */
    public TextField getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(TextField password) {
        this.password = password;
    }


    /**
     * @return the chatTA
     */
    public TextArea getChatTA() {
        return chatTA;
    }

    /**
     * @param chatTA the chatTA to set
     */
    public void setChatTA(TextArea chatTA) {
        this.chatTA = chatTA;
    }

    /**
     * @return the onlineList
     */
    public ListView getOnlineList() {
        return onlineList;
    }

    /**
     * @param onlineList the onlineList to set
     */
    public void setOnlineList(ListView onlineList) {
        this.onlineList = onlineList;
    }

    /**
     * @return the signInScene
     */
    public static Scene getSignInScene() {
        return signInScene;
    }

    /**
     * @return the caScene
     */
    public static Scene getCaScene() {
        return caScene;
    }

    /**
     * @return the stage
     */
    public static Stage getStage() {
        return stage;
    }

    /**
     * @param aStage the stage to set
     */
    public static void setStage(Stage aStage) {
        stage = aStage;
    }
    
    
    
}
