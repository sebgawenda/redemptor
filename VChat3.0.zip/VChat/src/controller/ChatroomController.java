/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author arman
 */
public class ChatroomController implements Initializable {

    @FXML
    private BorderPane chatroomBorderPane;
    @FXML
    private ToolBar chatroomTB;
    @FXML
    private Button joinBtn;
    @FXML
    private Button createBtn;
    @FXML
    private Button helpBtn;
    @FXML
    private Label messageLabel;
    @FXML
    private TextField messageTF;
    @FXML
    private Button attachBtn;
    @FXML
    private Button sendBtn;
    @FXML
    private TextArea chatTA;
    @FXML
    private Label userCRLabel;
    @FXML
    private Label idCRLabel;
    @FXML
    private Label chatroomNameLabel;
    @FXML
    private Label usersConnectedLabel;
    @FXML
    private ListView<?> onlineList;

    
//    private String fName = Singleton.getInstance().getfName().getText().trim();
//    private String lName = Singleton.getInstance().getlName().getText().trim();
    private String id = Singleton.getInstance().getId().getText().trim();
    //boolean connect = openConnection(address, port);
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        
    }    

    @FXML
    private void joinChatroom(ActionEvent event) {
    }

    @FXML
    private void createChatroom(ActionEvent event) {
    }

    @FXML
    private void helpInfo(ActionEvent event) {
    }

    @FXML
    private void attachFile(ActionEvent event) {
    }

    @FXML
    private void sendMessage(ActionEvent event) {
        send(messageTF.getText().trim());
    }
    
    @FXML
    private void sendMessageOnEnter(KeyEvent event) {
        if(event.getCode() == KeyCode.ENTER){
            send(messageTF.getText().trim());
        }
    }
    
    private void send(String message){
        if (message.equals("")) return;
        console(id + ": " + message);
        messageTF.clear();
    }
    
//    private boolean openConnection(String address, int port){
        
//    }
    
    public void console(String message){
        getChatTA().appendText(message + "\n");
    }

    /**
     * @return the chatTA
     */
    public TextArea getChatTA() {
        return chatTA;
    }

    /**
     * @param chatTA the chatTA to set
     */
    public void setChatTA(TextArea chatTA) {
        this.chatTA = chatTA;
    } 
    
}
