/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author arman
 */
public class SignInController extends StageFunctions implements Initializable {

    @FXML
    private Button loginBtn;
    @FXML
    private TextField idTF;
    @FXML
    private Button createAccountBtn;
    @FXML
    private Hyperlink forgot_pwHL;
    @FXML
    private ImageView signinLogo;
    @FXML
    private PasswordField passwordTF;
    @FXML
    private Label idLabel;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    
    @FXML
    private void loginOnEnter(KeyEvent event) {
        if(event.getCode() == KeyCode.ENTER){
            Singleton.getInstance().setId(getIdTF());
            Singleton.getInstance().setPassword(getPasswordTF());
            goToChatroomStage();
        }
    }    

    @FXML
    private void signIn(ActionEvent event) throws IOException {
        Singleton.getInstance().setId(getIdTF());
        Singleton.getInstance().setPassword(getPasswordTF());
        goToChatroomStage();  
    }
    

    @FXML
    private void createAccount(ActionEvent event) throws IOException{
        goToCreateAccountStage();   
    }
    
    private void goToCreateAccountStage(){
        hideCurrentStage();
        setStage("CreateAccount", "Sign Up");
    }
    
    private void goToChatroomStage(){
        hideCurrentStage();
        setStage("Chatroom", "VChat Client");
        
    }
    
    private void hideCurrentStage(){
        getLoginBtn().getScene().getWindow().hide();
 
    }
    
    /**
     * @return the loginBtn
     */
    public Button getLoginBtn() {
        return loginBtn;
    }

    /**
     * @param loginBtn the loginBtn to set
     */
    public void setLoginBtn(Button loginBtn) {
        this.loginBtn = loginBtn;
    }

    /**
     * @return the idTF
     */
    public TextField getIdTF() {
        return idTF;
    }

    /**
     * @param idTF the idTF to set
     */
    public void setIdTF(TextField idTF) {
        this.idTF = idTF;
    }

    /**
     * @return the createAccountBtn
     */
    public Button getCreateAccountBtn() {
        return createAccountBtn;
    }

    /**
     * @param createAccountBtn the createAccountBtn to set
     */
    public void setCreateAccountBtn(Button createAccountBtn) {
        this.createAccountBtn = createAccountBtn;
    }

    /**
     * @return the forgot_pwHL
     */
    public Hyperlink getForgot_pwHL() {
        return forgot_pwHL;
    }

    /**
     * @param forgot_pwHL the forgot_pwHL to set
     */
    public void setForgot_pwHL(Hyperlink forgot_pwHL) {
        this.forgot_pwHL = forgot_pwHL;
    }

    /**
     * @return the signinLogo
     */
    public ImageView getSigninLogo() {
        return signinLogo;
    }

    /**
     * @param signinLogo the signinLogo to set
     */
    public void setSigninLogo(ImageView signinLogo) {
        this.signinLogo = signinLogo;
    }

    /**
     * @return the passwordTF
     */
    public PasswordField getPasswordTF() {
        return passwordTF;
    }

    /**
     * @param passwordTF the passwordTF to set
     */
    public void setPasswordTF(PasswordField passwordTF) {
        this.passwordTF = passwordTF;
    }

    /**
     * @return the idLabel
     */
    public Label getIdLabel() {
        return idLabel;
    }

    /**
     * @param idLabel the idLabel to set
     */
    public void setIdLabel(Label idLabel) {
        this.idLabel = idLabel;
    }

   
    
}
