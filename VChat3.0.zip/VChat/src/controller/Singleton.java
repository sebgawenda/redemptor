/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javafx.scene.control.TextField;

/**
 *
 * @author arman
 */
public class Singleton {
    
    private static Singleton instance = new Singleton();
    public static Singleton getInstance(){
        return instance;
    }
    
    private TextField fName;
    private TextField lName;
    private TextField email;
    private TextField id;
    private TextField password;
    private TextField major;

    /**
     * @param aInstance the instance to set
     */
    public static void setInstance(Singleton aInstance) {
        instance = aInstance;
    }

    /**
     * @return the fName
     */
    public TextField getfName() {
        return fName;
    }

    /**
     * @param fName the fName to set
     */
    public void setfName(TextField fName) {
        this.fName = fName;
    }

    /**
     * @return the lName
     */
    public TextField getlName() {
        return lName;
    }

    /**
     * @param lName the lName to set
     */
    public void setlName(TextField lName) {
        this.lName = lName;
    }

    /**
     * @return the email
     */
    public TextField getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(TextField email) {
        this.email = email;
    }

    /**
     * @return the id
     */
    public TextField getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(TextField id) {
        this.id = id;
    }

    /**
     * @return the password
     */
    public TextField getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(TextField password) {
        this.password = password;
    }

    /**
     * @return the major
     */
    public TextField getMajor() {
        return major;
    }

    /**
     * @param major the major to set
     */
    public void setMajor(TextField major) {
        this.major = major;
    }
    
    
    
}
