/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import student.Student;
import view.*;
import vchat_client.*;


/**
 *
 * @author srv_veralab
 */
public class Controller {
    
    SignIn signIn;
    CreateAccount createAccount;
    Chatroom chatroom;
    VchatClient client;

    public Controller(SignIn signIn, CreateAccount createAccount, Chatroom chatroom, VchatClient client) {
        this.signIn = signIn;
        this.createAccount = createAccount;
        this.chatroom = chatroom;
        this.client = client;
        attachHandlers();
    }
    
    public void attachHandlers(){
       
        signIn.getLoginBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                /**
                * TODO
                * Gather information from login text field (here)
                * Connect to the Server thru the client (client)
                * Send student's id and password to the server (client)
                * Receive authentication from the server (client)
                *      if yes: goToChatroomStage and connect to server
                *      if no: Dialog Box: "Wrong username or password"
                */

               String id = "";
               String password = "";
               String ipAddress = "";

               id = signIn.getIdTF().getText().trim();
               password = signIn.getPasswordTF().getText().trim();
               ipAddress = signIn.getIpTF().getText().trim();

               Student student = new Student(id, password);

               client.connect(ipAddress);
            }	
        });
        
        signIn.getCreateAccountBtn().setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                /**
                * TODO
                * goToCreateAccountStage
                */
                CreateAccount createAccount = new CreateAccount();
                Pane root = (Pane) createAccount;
                Stage stage = new Stage();
                Scene scene = new Scene(root, 432, 460);
                stage.setTitle("Create Account");
                stage.setScene(scene);
                stage.show();
                stage.setResizable(false);
            }	
        });
        
        
    }  
}
